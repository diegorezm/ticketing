import { useState, useMemo } from 'react'
import { BoardColumn } from './board-column'
import { BoardFiltersBar } from './board-filters-bar'
import { mockStatuses } from './board-mock-data'
import type { BoardFilters, BoardStatus } from './board-types'

const emptyFilters: BoardFilters = {
  assignees: [],
  statuses: [],
  priorities: [],
  labels: [],
}

export function BoardView() {
  const [filters, setFilters] = useState<BoardFilters>(emptyFilters)
  const [search, setSearch] = useState('')

  const filteredStatuses: BoardStatus[] = useMemo(() => {
    return mockStatuses
      .filter((s) =>
        filters.statuses.length === 0 || filters.statuses.includes(s.id),
      )
      .map((status) => ({
        ...status,
        tickets: status.tickets.filter((ticket) => {
          if (
            search &&
            !ticket.title.toLowerCase().includes(search.toLowerCase())
          ) {
            return false
          }
          if (
            filters.assignees.length > 0 &&
            !ticket.assignees.some((a) => filters.assignees.includes(a.id))
          ) {
            return false
          }
          if (
            filters.priorities.length > 0 &&
            !filters.priorities.includes(ticket.priority)
          ) {
            return false
          }
          if (
            filters.labels.length > 0 &&
            !ticket.labels.some((l) => filters.labels.includes(l.id))
          ) {
            return false
          }
          return true
        }),
      }))
  }, [filters, search])

  return (
    <div className="flex flex-col h-full">
      <BoardFiltersBar
        filters={filters}
        onFiltersChange={setFilters}
        search={search}
        onSearchChange={setSearch}
      />

      {/* Board */}
      <div className="flex-1 overflow-x-auto">
        <div className="flex gap-4 p-4 h-full min-w-max">
          {filteredStatuses.map((status) => (
            <BoardColumn key={status.id} status={status} />
          ))}
        </div>
      </div>
    </div>
  )
}
